"""Part 3 -- turn the measured Gemini token counts into money.

Reads ``measurements.json`` from Part 2 and answers the three questions the
lab exists for:

* what one support request costs, in each language;
* what a year of them costs at a realistic volume;
* how much more a Kazakh-language service costs than an English one, for
  exactly the same work.

This Gemini-adapted version uses the real token measurements produced by the
modified ``part2_measure.py``. Thinking tokens are already included in the
``output_tokens`` field written by Part 2 and are billed at the output rate.

The annual projection uses current paid-tier list prices as an annualized
run-rate. The actual classroom experiment may cost $0 on an eligible free tier.

Run in Colab:
    %run part3_cost_gemini.py
    %run part3_cost_gemini.py --requests-per-day 5000
    %run part3_cost_gemini.py --output-tokens 300
    %run part3_cost_gemini.py --model gemini-3.6-flash
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Optional, Tuple

from texts import LANGUAGES


DEFAULT_MEASUREMENTS = Path(__file__).with_name("measurements.json")
FALLBACK_OUTPUT_TOKENS = 300

# Google Gemini Developer API paid-tier list prices, USD per 1M tokens.
# Checked 2026-09-21.
# Gemini 3.6 Flash rates below are the Standard rates through 2026-12-31.
# Output prices include thinking tokens.
PRICE_CHECKED = "2026-09-21"
PRICE_SOURCE = "https://ai.google.dev/gemini-api/docs/pricing"

PRICES = {
    "gemini-3.5-flash-lite": {"input": 0.30, "output": 2.50},
    "gemini-3.6-flash": {"input": 0.75, "output": 3.75},
    "gemini-3.8-flash": {"input": 0.75, "output": 4.50},
}

MODEL_ORDER = (
    "gemini-3.5-flash-lite",
    "gemini-3.6-flash",
    "gemini-3.8-flash",
)

DEFAULT_MODEL = "gemini-3.5-flash-lite"


def cost_usd(model_key: str, input_tokens: int, output_tokens: int) -> float:
    """Return paid-tier cost in USD for one request."""
    p = PRICES[model_key]
    return (
        input_tokens * p["input"] + output_tokens * p["output"]
    ) / 1_000_000


def load_measurements(path: Path) -> Dict[str, object]:
    """Read the JSON written by Part 2."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.exit(
            f"{path.name} not found. Run part2_measure.py --call first -- "
            "this script will not invent token counts."
        )
    except json.JSONDecodeError as exc:
        sys.exit(f"{path.name} is not valid JSON: {exc}")


def request_input_tokens(data: Dict[str, object], lang: str) -> int:
    """Return measured input tokens for one real request.

    Prefer the exact prompt_token_count returned by the real --call run. If the
    file only contains token-count preview data, fall back to request_tokens.
    """
    billed = data.get("one_request_billed")
    if billed and lang in billed and "input_tokens" in billed[lang]:
        return int(billed[lang]["input_tokens"])

    request_tokens = data.get("request_tokens")
    if request_tokens and lang in request_tokens:
        return int(request_tokens[lang])

    sys.exit(
        "measurements.json has no usable request input tokens for "
        f"{lang!r}. Re-run part2_measure.py --call."
    )


def resolve_output_tokens(
    billed: Optional[Dict[str, Dict[str, int]]], override: Optional[int]
) -> Tuple[Dict[str, int], str]:
    """Decide how many output tokens to charge for, per language."""
    if override is not None:
        return {lang: override for lang in LANGUAGES}, "fixed by --output-tokens"

    if billed and all(lang in billed for lang in LANGUAGES):
        return (
            {lang: int(billed[lang]["output_tokens"]) for lang in LANGUAGES},
            "measured in Part 2, including thinking tokens",
        )

    return (
        {lang: FALLBACK_OUTPUT_TOKENS for lang in LANGUAGES},
        "ASSUMED -- Part 2 ran without --call, so no answer was measured",
    )


def _header() -> str:
    return f"{'':<25}" + "".join(f"{lang.upper():>14}" for lang in LANGUAGES)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--measurements",
        type=Path,
        default=DEFAULT_MEASUREMENTS,
        help="path to the JSON written by part2_measure.py",
    )
    parser.add_argument(
        "--requests-per-day",
        type=int,
        default=2000,
        help="support volume to project (default: 2000)",
    )
    parser.add_argument(
        "--output-tokens",
        type=int,
        default=None,
        help="force one answer length for all languages instead of the measurement",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        choices=sorted(PRICES),
        help=f"model used for the final summary (default: {DEFAULT_MODEL})",
    )
    args = parser.parse_args()

    if args.requests_per_day <= 0:
        sys.exit("--requests-per-day must be greater than zero")
    if args.output_tokens is not None and args.output_tokens < 0:
        sys.exit("--output-tokens cannot be negative")

    data = load_measurements(args.measurements)
    outputs, provenance = resolve_output_tokens(
        data.get("one_request_billed"), args.output_tokens
    )
    inputs = {lang: request_input_tokens(data, lang) for lang in LANGUAGES}

    measured_model = data.get("model_id", "unknown")

    print(f"prices from {PRICE_SOURCE}")
    print(f"checked {PRICE_CHECKED}")
    print(f"tokens measured on {measured_model}")
    print(f"answer length: {provenance}")
    print(
        "NOTE: tables use paid-tier list prices for production planning. "
        "Eligible Free Tier usage can be $0."
    )
    if measured_model != DEFAULT_MODEL:
        print(
            "WARNING: token counts were measured on a different model than the "
            f"default pricing summary ({DEFAULT_MODEL})."
        )
    print()

    print("ONE SUPPORT REQUEST -- tokens and paid-tier cost in US cents")
    print("-" * 78)
    print(_header())
    print(f"{'input tokens':<25}" + "".join(f"{inputs[l]:>14}" for l in LANGUAGES))
    print(f"{'output tokens':<25}" + "".join(f"{outputs[l]:>14}" for l in LANGUAGES))

    for model_key in MODEL_ORDER:
        cents = [
            cost_usd(model_key, inputs[lang], outputs[lang]) * 100
            for lang in LANGUAGES
        ]
        print(f"{model_key:<25}" + "".join(f"{c:>14.4f}" for c in cents))

    per_year = args.requests_per_day * 365
    print(
        f"\nAT {args.requests_per_day:,} REQUESTS/DAY -- annualized paid-tier USD/year"
    )
    print("-" * 78)
    print(_header())
    for model_key in MODEL_ORDER:
        yearly = [
            cost_usd(model_key, inputs[lang], outputs[lang]) * per_year
            for lang in LANGUAGES
        ]
        print(f"{model_key:<25}" + "".join(f"{y:>14,.2f}" for y in yearly))

    print("\nTWO RATIOS THAT ARE NOT THE SAME NUMBER")
    print("-" * 78)
    print(_header())
    print(
        f"{'input only':<25}"
        + "".join(f"{inputs[l] / inputs['en']:>13.2f}x" for l in LANGUAGES)
    )

    base_bill = cost_usd(args.model, inputs["en"], outputs["en"])
    print(
        f"{'total bill':<25}"
        + "".join(
            f"{cost_usd(args.model, inputs[l], outputs[l]) / base_bill:>13.2f}x"
            for l in LANGUAGES
        )
    )

    print(
        "\nThe input-only row describes tokenizer/request expansion. The total-bill "
        "row also includes the measured answer and thinking tokens, so the two "
        "ratios do not have to match."
    )

    print("\nTHE NUMBER TO REMEMBER")
    print("-" * 78)
    en_year = cost_usd(args.model, inputs["en"], outputs["en"]) * per_year
    for lang in ("ru", "kk"):
        lang_year = cost_usd(args.model, inputs[lang], outputs[lang]) * per_year
        print(
            f"{lang.upper()} instead of EN on {args.model}, same volume: "
            f"${lang_year - en_year:,.2f}/year more "
            f"({lang_year / en_year:.2f}x total bill)."
        )

    print(
        "\nImportant: costs for models other than the model used in Part 2 are "
        "price projections using the same measured token volumes. For a strict "
        "model-to-model comparison, rerun Part 2 on each model because token usage "
        "and answer length can change by model."
    )

    return 0


if __name__ == "__main__":
    sys.exit(main())
