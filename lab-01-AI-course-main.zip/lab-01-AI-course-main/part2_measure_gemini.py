"""Part 2 -- the measurement, adapted for Google Gemini + Google Colab.

Does two things:

1. One real request per language, so you can see the response and the token
   usage returned by Gemini. Three calls are used because answer length can be
   language-dependent.
2. Token counts for every text in :mod:`texts`, in every language, plus one
   combined count per language for the real request shape (system prompt +
   complaint) that Part 3 will price.

Results are written to ``measurements.json`` for Part 3.

Google Colab setup:
    1. Put your key in Colab Secrets as GEMINI_API_KEY and enable notebook access.
    2. Install the SDK once:
           !pip install -q -U google-genai

Run:
    !python part2_measure.py            # count tokens only
    !python part2_measure.py --call     # also answer complaint in en, ru, kk

The default model is Gemini 3.8 Flash Lite. You can override it, for example:
    !python part2_measure.py --model gemini-3.5-flash-Lite --call
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, Optional

try:
    from google import genai
    from google.genai import types
except ImportError:
    print(
        "google-genai is not installed. In Colab run: !pip install -q -U google-genai",
        file=sys.stderr,
    )
    raise

from texts import CORPUS, LANGUAGES


OUTPUT_PATH = Path(__file__).with_name("measurements.json")
DEFAULT_MODEL = "gemini-3.5-flash-lite"
MAX_TOKENS = 2048


def get_api_key() -> Optional[str]:
    """Load GEMINI_API_KEY from environment or, in Colab, from Secrets."""
    key = os.getenv("GEMINI_API_KEY")
    if key:
        return key

    # This makes the file work directly in Google Colab when the key is stored
    # under the Secrets (key icon) name GEMINI_API_KEY.
    try:
        from google.colab import userdata  # type: ignore

        key = userdata.get("GEMINI_API_KEY")
        if key:
            return key
    except Exception:
        pass

    return None


def count_tokens(client: genai.Client, model_id: str, text: str) -> int:
    """Return Gemini's token count for one standalone text."""
    result = client.models.count_tokens(
        model=model_id,
        contents=text,
    )
    return int(result.total_tokens or 0)


def count_request_tokens(client: genai.Client, model_id: str, lang: str) -> int:
    """Pre-count system prompt + complaint without generating a response.

    Gemini's Developer API currently rejects ``system_instruction`` on the
    ``count_tokens`` call for this model/account path.  For the no-generation
    preview we therefore count the two pieces together as plain input text.

    When ``--call`` is used, this preview is replaced in ``measurements.json``
    by Gemini's exact ``prompt_token_count`` from the real request, where the
    system prompt *is* sent as a true system instruction.
    """
    combined = (
        "[SYSTEM]\n"
        + CORPUS["system_prompt"][lang]
        + "\n\n[USER]\n"
        + CORPUS["complaint"][lang]
    )
    result = client.models.count_tokens(
        model=model_id,
        contents=combined,
    )
    return int(result.total_tokens or 0)


def one_real_request(
    client: genai.Client, model_id: str, lang: str
) -> Optional[Dict[str, int]]:
    """Send one Gemini request and print the answer and billed token usage.

    Gemini thinking tokens are billed at the output-token rate. Therefore the
    ``output_tokens`` field saved for Part 3 is:

        visible output tokens + thinking tokens

    Extra fields are also saved so you can inspect the breakdown.
    """
    response = client.models.generate_content(
        model=model_id,
        contents=CORPUS["complaint"][lang],
        config=types.GenerateContentConfig(
            system_instruction=CORPUS["system_prompt"][lang],
            max_output_tokens=MAX_TOKENS,
        ),
    )

    # A blocked/empty response may have no printable text.
    answer = response.text or ""
    if not answer.strip():
        print("  model returned no visible text")
    else:
        print("  --- answer ---")
        print("  " + answer.replace("\n", "\n  "))

    usage = response.usage_metadata
    if usage is None:
        print("  no usage metadata returned")
        return None

    input_tokens = int(usage.prompt_token_count or 0)
    visible_output_tokens = int(usage.candidates_token_count or 0)
    thinking_tokens = int(usage.thoughts_token_count or 0)
    billed_output_tokens = visible_output_tokens + thinking_tokens
    total_tokens = int(usage.total_token_count or 0)

    print(
        "  usage: "
        f"{input_tokens} in, "
        f"{visible_output_tokens} visible out, "
        f"{thinking_tokens} thinking, "
        f"{billed_output_tokens} billed out"
    )
    if total_tokens:
        print(f"  total tokens reported by API: {total_tokens}")

    return {
        "input_tokens": input_tokens,
        # Keep this key compatible with the original Part 3 idea: it is the
        # output quantity that should be priced.
        "output_tokens": billed_output_tokens,
        "visible_output_tokens": visible_output_tokens,
        "thinking_tokens": thinking_tokens,
    }


def main() -> int:
    """Count tokens for the whole corpus, optionally make one real request."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Gemini model id (default: {DEFAULT_MODEL})",
    )
    parser.add_argument(
        "--call",
        action="store_true",
        help="also answer the complaint in each language (uses real API calls)",
    )
    args = parser.parse_args()

    api_key = get_api_key()
    if not api_key:
        print("GEMINI_API_KEY was not found.", file=sys.stderr)
        print(
            "In Colab: open Secrets (key icon), add GEMINI_API_KEY, "
            "and enable Notebook access.",
            file=sys.stderr,
        )
        return 1

    model_id = args.model
    client = genai.Client(api_key=api_key)

    counts: Dict[str, Dict[str, int]] = {}
    print(f"counting tokens on {model_id}")

    try:
        for item_id, versions in CORPUS.items():
            counts[item_id] = {
                lang: count_tokens(client, model_id, versions[lang])
                for lang in LANGUAGES
            }
            row = "  ".join(
                f"{lang}={counts[item_id][lang]}" for lang in LANGUAGES
            )
            print(f"  {item_id:<14} {row}")

        request_tokens: Dict[str, int] = {
            lang: count_request_tokens(client, model_id, lang) for lang in LANGUAGES
        }
        row = "  ".join(f"{lang}={request_tokens[lang]}" for lang in LANGUAGES)
        print(
            f"  {'request':<14} {row}  "
            "(system + complaint preview; exact count replaces it with --call)"
        )
    except Exception as exc:
        print(f"Gemini API error while counting tokens: {exc}", file=sys.stderr)
        return 1

    billed: Dict[str, Dict[str, int]] = {}
    if args.call:
        print(f"\nanswering the same complaint on {model_id}, in each language:")
        for lang in LANGUAGES:
            print(f"\n[{lang}]")
            try:
                result = one_real_request(client, model_id, lang)
            except Exception as exc:
                print(f"Gemini API error: {exc}", file=sys.stderr)
                return 1
            if result is not None:
                billed[lang] = result
                # Prefer exact prompt usage from the real call over the
                # pre-count, so the saved measurement matches actual usage.
                request_tokens[lang] = result["input_tokens"]

    payload = {
        "provider": "Google Gemini",
        "model": model_id,
        "model_id": model_id,
        "token_counts": counts,
        "request_tokens": request_tokens,
        "one_request_billed": billed or None,
    }
    OUTPUT_PATH.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"\nwrote {OUTPUT_PATH.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
