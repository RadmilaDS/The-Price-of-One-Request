"""Gemini API list prices, in US dollars per million tokens.

Prices change. This table is a snapshot, so check the official
Gemini API pricing page before quoting numbers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


PRICE_SOURCE = "https://ai.google.dev/gemini-api/docs/pricing"
PRICE_CHECKED = "2026-09-21"


@dataclass(frozen=True)
class Model:
    """One model's list price and context limit."""

    model_id: str
    input_per_mtok: float
    output_per_mtok: float
    context_tokens: int


MODELS: Dict[str, Model] = {
    "gemini-3.5-flash-lite": Model(
        "gemini-3.5-flash-lite",
        0.30,
        2.50,
        1_048_576,
    ),

    "gemini-3.6-flash": Model(
        "gemini-3.6-flash",
        0.75,
        3.75,
        1_048_576,
    ),

    "gemini-3.8-flash": Model(
        "gemini-3.8-flash",
        0.75,
        3.75,
        1_048_576,
    ),
}


DEFAULT_MODEL = "gemini-3.5-flash-lite"


def cost_usd(
    model_key: str,
    input_tokens: int,
    output_tokens: int
) -> float:
    """Return the list-price cost of one request, in US dollars."""

    model = MODELS[model_key]

    return (
        input_tokens * model.input_per_mtok
        + output_tokens * model.output_per_mtok
    ) / 1_000_000
